from flask import Flask, request, jsonify
import stanza
import nltk
from nltk.tree import Tree

app = Flask(__name__)

# Load stanza model
stanza.download('en', processors='tokenize,pos,depparse', verbose=False)
nlp = stanza.Pipeline('en', processors='tokenize,mwt,pos,lemma,depparse')

# Load ISL supported words
with open("words.txt", "r") as f:
    ISL_WORDS = set([w.strip().lower() for w in f.readlines()])


def english_to_isl(sentence):
    doc = nlp(sentence)
    isl_output = []

    for sent in doc.sentences:
        subject = []
        verb = []
        obj = []
        others = []

        for word in sent.words:
            if word.deprel in ["nsubj", "nsubj:pass"]:
                subject.append(word.text.lower())
            elif word.upos == "VERB":
                verb.append(word.text.lower())
            elif word.deprel in ["obj", "iobj"]:
                obj.append(word.text.lower())
            else:
                others.append(word.text.lower())

        # ISL Order: SUBJECT OBJECT VERB
        isl_output = subject + obj + others + verb

    final_tokens = []
    for word in isl_output:
        if word in ISL_WORDS:
            final_tokens.append(word)
        else:
            # Split unknown word into letters
            final_tokens.extend(list(word))

    return final_tokens


@app.route("/translate", methods=["POST"])
def translate():
    data = request.get_json()
    text = data.get("text", "")

    if not text:
        return jsonify({"error": "No text provided"}), 400

    isl_tokens = english_to_isl(text)
    return jsonify({
        "input": text,
        "isl_gloss": isl_tokens
    })


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)