import 'package:flutter/material.dart';
import 'widgets/camera_view.dart';
import 'widgets/translation_output.dart';
import 'widgets/text_input.dart';
import 'widgets/sign_language_avatar.dart';
import 'widgets/mode_switcher.dart';

enum Mode { signToText, textToSign }

class SignSpeakApp extends StatelessWidget {
  const SignSpeakApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'SignSpeak',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: Colors.indigo,
      ),
      home: const HomeScreen(),
    );
  }
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  Mode mode = Mode.signToText;
  bool isRecording = false;
  String translatedText = '';
  String inputText = '';

  void startRecording() {
    setState(() => isRecording = true);
    Future.delayed(const Duration(seconds: 2), () {
      setState(() {
        translatedText = "Hello, how are you today?";
      });
    });
  }

  void stopRecording() {
    setState(() => isRecording = false);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Row(
          children: [
            Icon(Icons.videocam),
            SizedBox(width: 8),
            Text("SignSpeak"),
          ],
        ),
        actions: const [
          Padding(
            padding: EdgeInsets.only(right: 12),
            child: Icon(Icons.settings),
          )
        ],
      ),
      body: Column(
        children: [
          ModeSwitcher(
            mode: mode,
            onChange: (m) => setState(() => mode = m),
          ),
          Expanded(
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: mode == Mode.signToText
                  ? Column(
                      children: [
                        Expanded(
                          child: CameraView(
                            isRecording: isRecording,
                            onStart: startRecording,
                            onStop: stopRecording,
                          ),
                        ),
                        const SizedBox(height: 12),
                        SizedBox(
                          height: 120,
                          child: TranslationOutput(text: translatedText),
                        )
                      ],
                    )
                  : Column(
                      children: [
                        SizedBox(
                          height: 160,
                          child: TextInputWidget(
                            onSubmit: (txt) =>
                                setState(() => inputText = txt),
                          ),
                        ),
                        const SizedBox(height: 12),
                        Expanded(
                          child: SignLanguageAvatar(text: inputText),
                        ),
                      ],
                    ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(12),
            child: Text(
              mode == Mode.signToText
                  ? "Position your hands and start recording"
                  : "Enter text to see sign language",
              style: const TextStyle(color: Colors.grey),
            ),
          )
        ],
      ),
    );
  }
}
