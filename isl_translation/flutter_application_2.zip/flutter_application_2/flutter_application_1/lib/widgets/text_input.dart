import 'package:flutter/material.dart';

class TextInputWidget extends StatefulWidget {
  final ValueChanged<String> onSubmit;

  const TextInputWidget({super.key, required this.onSubmit});

  @override
  State<TextInputWidget> createState() => _TextInputWidgetState();
}

class _TextInputWidgetState extends State<TextInputWidget> {
  final controller = TextEditingController();

  final quickPhrases = ["Hello", "Thank you", "Yes", "How are you?"];

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 4,
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          children: [
            TextField(
              controller: controller,
              decoration: InputDecoration(
                labelText: "Enter text",
                suffixIcon: IconButton(
                  icon: const Icon(Icons.send),
                  onPressed: () => widget.onSubmit(controller.text),
                ),
              ),
            ),
            const SizedBox(height: 12),
            Wrap(
              spacing: 8,
              children: quickPhrases.map((p) {
                return ActionChip(
                  label: Text(p),
                  onPressed: () {
                    controller.text = p;
                    widget.onSubmit(p);
                  },
                );
              }).toList(),
            )
          ],
        ),
      ),
    );
  }
}
