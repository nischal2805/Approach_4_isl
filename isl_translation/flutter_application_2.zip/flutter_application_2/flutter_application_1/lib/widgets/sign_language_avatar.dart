import 'package:flutter/material.dart';

class SignLanguageAvatar extends StatelessWidget {
  final String text;

  const SignLanguageAvatar({super.key, required this.text});

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 4,
      child: Column(
        children: [
          const ListTile(
            leading: Icon(Icons.person),
            title: Text("Sign Language Demonstration"),
          ),
          Expanded(
            child: Center(
              child: Text(
                text.isEmpty
                    ? "Enter text to see sign language"
                    : 'Signing: "$text"',
                style: const TextStyle(fontSize: 18),
              ),
            ),
          )
        ],
      ),
    );
  }
}
