import 'package:flutter/material.dart';

class CameraView extends StatelessWidget {
  final bool isRecording;
  final VoidCallback onStart;
  final VoidCallback onStop;

  const CameraView({
    super.key,
    required this.isRecording,
    required this.onStart,
    required this.onStop,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 4,
      child: Column(
        children: [
          ListTile(
            leading: const Icon(Icons.videocam),
            title: const Text("Camera Feed"),
            trailing: isRecording
                ? const Chip(
                    label: Text("Recording"),
                    backgroundColor: Colors.redAccent,
                  )
                : null,
          ),
          Expanded(
            child: Container(
              color: Colors.black87,
              child: Center(
                child: Icon(
                  Icons.pan_tool,
                  size: 100,
                  color: Colors.grey.shade700,
                ),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(12),
            child: ElevatedButton.icon(
              icon: Icon(isRecording ? Icons.stop : Icons.circle),
              label: Text(isRecording ? "Stop Recording" : "Start Recording"),
              style: ElevatedButton.styleFrom(
                backgroundColor:
                    isRecording ? Colors.red : Colors.indigo,
                foregroundColor: Colors.white,
                minimumSize: const Size.fromHeight(48),
              ),
              onPressed: isRecording ? onStop : onStart,
            ),
          )
        ],
      ),
    );
  }
}
