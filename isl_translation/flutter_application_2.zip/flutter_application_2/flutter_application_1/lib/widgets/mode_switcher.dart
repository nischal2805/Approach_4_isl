import 'package:flutter/material.dart';
import '../app.dart';

class ModeSwitcher extends StatelessWidget {
  final Mode mode;
  final ValueChanged<Mode> onChange;

  const ModeSwitcher({super.key, required this.mode, required this.onChange});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(8),
      child: SegmentedButton<Mode>(
        segments: const [
          ButtonSegment(
            value: Mode.signToText,
            icon: Icon(Icons.camera_alt),
            label: Text("Sign → Text"),
          ),
          ButtonSegment(
            value: Mode.textToSign,
            icon: Icon(Icons.text_fields),
            label: Text("Text → Sign"),
          ),
        ],
        selected: {mode},
        onSelectionChanged: (v) => onChange(v.first),
      ),
    );
  }
}
