import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class TranslationOutput extends StatelessWidget {
  final String text;

  const TranslationOutput({super.key, required this.text});

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 4,
      child: Column(
        children: [
          ListTile(
            leading: const Icon(Icons.message),
            title: const Text("Translation"),
            trailing: text.isNotEmpty
                ? IconButton(
                    icon: const Icon(Icons.copy),
                    onPressed: () {
                      Clipboard.setData(ClipboardData(text: text));
                    },
                  )
                : null,
          ),
          Expanded(
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: text.isEmpty
                  ? const Text(
                      "Translation will appear here...",
                      style: TextStyle(color: Colors.grey),
                    )
                  : Text(text),
            ),
          )
        ],
      ),
    );
  }
}
